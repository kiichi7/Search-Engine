﻿namespace nSearch.Tedit
{
    partial class FormParseST
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormParseST));
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.textBox_h = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.textBox_m = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox_TA2 = new System.Windows.Forms.TextBox();
            this.textBox_TA1 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox_t = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox_e = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_d = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_c = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_b = new System.Windows.Forms.TextBox();
            this.textBox_a = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.textBox_TAc2 = new System.Windows.Forms.TextBox();
            this.textBox_TAc1 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.textBox_d1 = new System.Windows.Forms.TextBox();
            this.textBox_c1 = new System.Windows.Forms.TextBox();
            this.webBrowser_d = new System.Windows.Forms.WebBrowser();
            this.webBrowser_c = new System.Windows.Forms.WebBrowser();
            this.textBox_e1 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox_b1 = new System.Windows.Forms.TextBox();
            this.textBox_a1 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.textBox_f = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.comboBox_f = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(17, 17);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(156, 268);
            this.listBox1.TabIndex = 0;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(189, 44);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(681, 433);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.textBox13);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.listBox2);
            this.tabPage1.Controls.Add(this.textBox_h);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Location = new System.Drawing.Point(4, 21);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(673, 408);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "数据";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(469, 90);
            this.textBox13.Multiline = true;
            this.textBox13.Name = "textBox13";
            this.textBox13.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox13.Size = new System.Drawing.Size(208, 303);
            this.textBox13.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(98, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 12);
            this.label1.TabIndex = 4;
            this.label1.Text = "名称 * * * * *";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(22, 244);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 12);
            this.label14.TabIndex = 5;
            this.label14.Text = "调试列表";
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 12;
            this.listBox2.Location = new System.Drawing.Point(81, 90);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(382, 304);
            this.listBox2.TabIndex = 4;
            this.listBox2.SelectedIndexChanged += new System.EventHandler(this.listBox2_SelectedIndexChanged);
            // 
            // textBox_h
            // 
            this.textBox_h.Location = new System.Drawing.Point(81, 31);
            this.textBox_h.Multiline = true;
            this.textBox_h.Name = "textBox_h";
            this.textBox_h.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_h.Size = new System.Drawing.Size(586, 53);
            this.textBox_h.TabIndex = 1;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(22, 31);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(47, 12);
            this.label12.TabIndex = 0;
            this.label12.Text = "过滤器H";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.textBox_m);
            this.tabPage2.Controls.Add(this.label16);
            this.tabPage2.Controls.Add(this.textBox_TA2);
            this.tabPage2.Controls.Add(this.textBox_TA1);
            this.tabPage2.Controls.Add(this.label20);
            this.tabPage2.Controls.Add(this.label19);
            this.tabPage2.Controls.Add(this.textBox_t);
            this.tabPage2.Controls.Add(this.label18);
            this.tabPage2.Controls.Add(this.textBox_e);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.textBox_d);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.textBox_c);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.textBox_b);
            this.tabPage2.Controls.Add(this.textBox_a);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Location = new System.Drawing.Point(4, 21);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(673, 408);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "结构";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // textBox_m
            // 
            this.textBox_m.Location = new System.Drawing.Point(95, 45);
            this.textBox_m.Name = "textBox_m";
            this.textBox_m.Size = new System.Drawing.Size(68, 21);
            this.textBox_m.TabIndex = 19;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.ForeColor = System.Drawing.Color.Red;
            this.label16.Location = new System.Drawing.Point(22, 48);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 12);
            this.label16.TabIndex = 18;
            this.label16.Text = "主类别 M";
            // 
            // textBox_TA2
            // 
            this.textBox_TA2.Location = new System.Drawing.Point(522, 48);
            this.textBox_TA2.Name = "textBox_TA2";
            this.textBox_TA2.Size = new System.Drawing.Size(135, 21);
            this.textBox_TA2.TabIndex = 15;
            // 
            // textBox_TA1
            // 
            this.textBox_TA1.Location = new System.Drawing.Point(297, 51);
            this.textBox_TA1.Name = "textBox_TA1";
            this.textBox_TA1.Size = new System.Drawing.Size(122, 21);
            this.textBox_TA1.TabIndex = 14;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ForeColor = System.Drawing.Color.Red;
            this.label20.Location = new System.Drawing.Point(451, 51);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(47, 12);
            this.label20.TabIndex = 13;
            this.label20.Text = "类别2 *";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.Color.Red;
            this.label19.Location = new System.Drawing.Point(209, 51);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(47, 12);
            this.label19.TabIndex = 12;
            this.label19.Text = "类别1 *";
            // 
            // textBox_t
            // 
            this.textBox_t.Location = new System.Drawing.Point(103, 246);
            this.textBox_t.Name = "textBox_t";
            this.textBox_t.Size = new System.Drawing.Size(536, 21);
            this.textBox_t.TabIndex = 11;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(18, 249);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(59, 12);
            this.label18.TabIndex = 10;
            this.label18.Text = "Title模型";
            // 
            // textBox_e
            // 
            this.textBox_e.Location = new System.Drawing.Point(111, 78);
            this.textBox_e.Multiline = true;
            this.textBox_e.Name = "textBox_e";
            this.textBox_e.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_e.Size = new System.Drawing.Size(546, 162);
            this.textBox_e.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(22, 78);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 12);
            this.label6.TabIndex = 8;
            this.label6.Text = "索引用的数据E";
            // 
            // textBox_d
            // 
            this.textBox_d.Location = new System.Drawing.Point(425, 327);
            this.textBox_d.Multiline = true;
            this.textBox_d.Name = "textBox_d";
            this.textBox_d.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_d.Size = new System.Drawing.Size(223, 51);
            this.textBox_d.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(339, 330);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 12);
            this.label5.TabIndex = 6;
            this.label5.Text = "快照显示D ";
            // 
            // textBox_c
            // 
            this.textBox_c.Location = new System.Drawing.Point(114, 327);
            this.textBox_c.Multiline = true;
            this.textBox_c.Name = "textBox_c";
            this.textBox_c.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_c.Size = new System.Drawing.Size(208, 63);
            this.textBox_c.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(37, 330);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 12);
            this.label4.TabIndex = 4;
            this.label4.Text = "简要显示C";
            // 
            // textBox_b
            // 
            this.textBox_b.Location = new System.Drawing.Point(114, 278);
            this.textBox_b.Multiline = true;
            this.textBox_b.Name = "textBox_b";
            this.textBox_b.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_b.Size = new System.Drawing.Size(544, 43);
            this.textBox_b.TabIndex = 3;
            // 
            // textBox_a
            // 
            this.textBox_a.Location = new System.Drawing.Point(95, 16);
            this.textBox_a.Name = "textBox_a";
            this.textBox_a.Size = new System.Drawing.Size(562, 21);
            this.textBox_a.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(28, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 12);
            this.label3.TabIndex = 1;
            this.label3.Text = "标题A *";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 278);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "类聚B";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.textBox_TAc2);
            this.tabPage3.Controls.Add(this.textBox_TAc1);
            this.tabPage3.Controls.Add(this.label21);
            this.tabPage3.Controls.Add(this.label22);
            this.tabPage3.Controls.Add(this.textBox_d1);
            this.tabPage3.Controls.Add(this.textBox_c1);
            this.tabPage3.Controls.Add(this.webBrowser_d);
            this.tabPage3.Controls.Add(this.webBrowser_c);
            this.tabPage3.Controls.Add(this.textBox_e1);
            this.tabPage3.Controls.Add(this.label7);
            this.tabPage3.Controls.Add(this.label8);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Controls.Add(this.textBox_b1);
            this.tabPage3.Controls.Add(this.textBox_a1);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Location = new System.Drawing.Point(4, 21);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(673, 408);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "结果";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // textBox_TAc2
            // 
            this.textBox_TAc2.Location = new System.Drawing.Point(383, 48);
            this.textBox_TAc2.Name = "textBox_TAc2";
            this.textBox_TAc2.Size = new System.Drawing.Size(135, 21);
            this.textBox_TAc2.TabIndex = 27;
            // 
            // textBox_TAc1
            // 
            this.textBox_TAc1.Location = new System.Drawing.Point(158, 51);
            this.textBox_TAc1.Name = "textBox_TAc1";
            this.textBox_TAc1.Size = new System.Drawing.Size(122, 21);
            this.textBox_TAc1.TabIndex = 26;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.Color.Red;
            this.label21.Location = new System.Drawing.Point(312, 51);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(35, 12);
            this.label21.TabIndex = 25;
            this.label21.Text = "类别2";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.ForeColor = System.Drawing.Color.Red;
            this.label22.Location = new System.Drawing.Point(70, 51);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(35, 12);
            this.label22.TabIndex = 24;
            this.label22.Text = "类别1";
            // 
            // textBox_d1
            // 
            this.textBox_d1.Location = new System.Drawing.Point(373, 311);
            this.textBox_d1.Multiline = true;
            this.textBox_d1.Name = "textBox_d1";
            this.textBox_d1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_d1.Size = new System.Drawing.Size(283, 82);
            this.textBox_d1.TabIndex = 23;
            // 
            // textBox_c1
            // 
            this.textBox_c1.Location = new System.Drawing.Point(30, 311);
            this.textBox_c1.Multiline = true;
            this.textBox_c1.Name = "textBox_c1";
            this.textBox_c1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_c1.Size = new System.Drawing.Size(271, 82);
            this.textBox_c1.TabIndex = 22;
            // 
            // webBrowser_d
            // 
            this.webBrowser_d.Location = new System.Drawing.Point(373, 274);
            this.webBrowser_d.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser_d.Name = "webBrowser_d";
            this.webBrowser_d.Size = new System.Drawing.Size(278, 31);
            this.webBrowser_d.TabIndex = 21;
            this.webBrowser_d.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(this.webBrowser2_DocumentCompleted);
            // 
            // webBrowser_c
            // 
            this.webBrowser_c.Location = new System.Drawing.Point(34, 274);
            this.webBrowser_c.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser_c.Name = "webBrowser_c";
            this.webBrowser_c.Size = new System.Drawing.Size(267, 31);
            this.webBrowser_c.TabIndex = 20;
            // 
            // textBox_e1
            // 
            this.textBox_e1.Location = new System.Drawing.Point(72, 93);
            this.textBox_e1.Multiline = true;
            this.textBox_e1.Name = "textBox_e1";
            this.textBox_e1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_e1.Size = new System.Drawing.Size(579, 97);
            this.textBox_e1.TabIndex = 19;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(14, 78);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 12);
            this.label7.TabIndex = 18;
            this.label7.Text = "索引用的数据E";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(371, 257);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 12);
            this.label8.TabIndex = 16;
            this.label8.Text = "快照显示D";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(32, 257);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 12);
            this.label9.TabIndex = 14;
            this.label9.Text = "简要显示C";
            // 
            // textBox_b1
            // 
            this.textBox_b1.Location = new System.Drawing.Point(70, 214);
            this.textBox_b1.Multiline = true;
            this.textBox_b1.Name = "textBox_b1";
            this.textBox_b1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_b1.Size = new System.Drawing.Size(603, 40);
            this.textBox_b1.TabIndex = 13;
            // 
            // textBox_a1
            // 
            this.textBox_a1.Location = new System.Drawing.Point(64, 19);
            this.textBox_a1.Name = "textBox_a1";
            this.textBox_a1.Size = new System.Drawing.Size(603, 21);
            this.textBox_a1.TabIndex = 12;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(14, 22);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 12);
            this.label10.TabIndex = 11;
            this.label10.Text = "标题A";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(20, 214);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 12);
            this.label11.TabIndex = 10;
            this.label11.Text = "类聚B";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.textBox_f);
            this.tabPage4.Controls.Add(this.textBox7);
            this.tabPage4.Location = new System.Drawing.Point(4, 21);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(673, 408);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "其它";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // textBox_f
            // 
            this.textBox_f.Location = new System.Drawing.Point(19, 17);
            this.textBox_f.Multiline = true;
            this.textBox_f.Name = "textBox_f";
            this.textBox_f.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_f.Size = new System.Drawing.Size(633, 92);
            this.textBox_f.TabIndex = 22;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(19, 115);
            this.textBox7.Multiline = true;
            this.textBox7.Name = "textBox7";
            this.textBox7.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox7.Size = new System.Drawing.Size(633, 236);
            this.textBox7.TabIndex = 20;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(811, 15);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(39, 20);
            this.button3.TabIndex = 21;
            this.button3.Text = "测试";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // comboBox_f
            // 
            this.comboBox_f.FormattingEnabled = true;
            this.comboBox_f.Location = new System.Drawing.Point(296, 15);
            this.comboBox_f.Name = "comboBox_f";
            this.comboBox_f.Size = new System.Drawing.Size(504, 20);
            this.comboBox_f.TabIndex = 18;
            this.comboBox_f.SelectedIndexChanged += new System.EventHandler(this.comboBox_f_SelectedIndexChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(201, 21);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(83, 12);
            this.label15.TabIndex = 14;
            this.label15.Text = "采样结果列表F";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(18, 423);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(71, 20);
            this.button1.TabIndex = 2;
            this.button1.Text = "保存";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(101, 423);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(72, 19);
            this.button2.TabIndex = 3;
            this.button2.Text = "删除";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(788, 15);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(95, 24);
            this.button5.TabIndex = 5;
            this.button5.Text = "加载";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(12, 18);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(77, 12);
            this.label17.TabIndex = 6;
            this.label17.Text = "模板文件路径";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(104, 15);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(662, 21);
            this.textBox14.TabIndex = 7;
            this.textBox14.Text = " ";
            this.textBox14.TextChanged += new System.EventHandler(this.textBox14_TextChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.linkLabel1);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.tabControl1);
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.listBox1);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.comboBox_f);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Enabled = false;
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.groupBox1.Location = new System.Drawing.Point(12, 62);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(876, 483);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(20, 461);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(167, 12);
            this.linkLabel1.TabIndex = 43;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "http://blog.163.com/zd4004/";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = global::nSearch.Tedit.Properties.Resources.xl2;
            this.pictureBox1.Location = new System.Drawing.Point(36, 314);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(81, 103);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 42;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(104, 42);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(662, 21);
            this.textBox1.TabIndex = 10;
            this.textBox1.Text = " ";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(12, 45);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(77, 12);
            this.label13.TabIndex = 9;
            this.label13.Text = "文件系统路径";
            // 
            // FormParseST
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(895, 546);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.button5);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormParseST";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "过滤模板管理器";
            this.Load += new System.EventHandler(this.FormParseST_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_b;
        private System.Windows.Forms.TextBox textBox_a;
        private System.Windows.Forms.TextBox textBox_c;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_d;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TextBox textBox_e;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_h;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox_e1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox_b1;
        private System.Windows.Forms.TextBox textBox_a1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.WebBrowser webBrowser_d;
        private System.Windows.Forms.WebBrowser webBrowser_c;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.ComboBox comboBox_f;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox_t;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox_f;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox_d1;
        private System.Windows.Forms.TextBox textBox_c1;
        private System.Windows.Forms.TextBox textBox_TA2;
        private System.Windows.Forms.TextBox textBox_TA1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox_TAc2;
        private System.Windows.Forms.TextBox textBox_TAc1;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBox_m;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.LinkLabel linkLabel1;
    }
}